import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { useJobPreferences } from '../hooks'
import type { JobPreferences } from '../hooks/useJobPreferences'
import { Container } from '../components/shared/Container'
import {
  PreferencesIcon,
  JobsIcon,
  AutoApplyIcon,
  MatchScoreIcon,
} from '../components/icons/RelevntIcons'

type ChipField =
  | 'related_titles'
  | 'preferred_locations'
  | 'allowed_timezones'
  | 'exclude_titles'
  | 'exclude_companies'
  | 'exclude_contract_types'
  | 'include_keywords'
  | 'avoid_keywords'

const seniorityOptions = ['Junior', 'Mid level', 'Senior', 'Lead', 'Director']
const locationOptions = ['Remote', 'Hybrid', 'On site', 'Flexible']
const currencyOptions = ['USD', 'CAD', 'EUR', 'GBP']
const salaryUnitOptions = ['yearly', 'hourly']

export default function JobPreferencesPage(): JSX.Element {
  const {
    prefs,
    loading,
    saving,
    error,
    saveStatus,
    setField,
    save,
  } = useJobPreferences()

  const [chipDrafts, setChipDrafts] = useState<Record<ChipField, string>>({
    related_titles: '',
    preferred_locations: '',
    allowed_timezones: '',
    exclude_titles: '',
    exclude_companies: '',
    exclude_contract_types: '',
    include_keywords: '',
    avoid_keywords: '',
  })

  const updateField = <K extends keyof JobPreferences>(
    key: K,
    value: JobPreferences[K]
  ) => {
    if (!prefs) return
    setField(key, value)
  }

  const addChip = (field: ChipField) => {
    if (!prefs) return
    const draft = chipDrafts[field].trim()
    if (!draft) return
    const current = (prefs[field] as string[]) || []
    updateField(field as any, [...current, draft] as any)
    setChipDrafts({ ...chipDrafts, [field]: '' })
  }

  const removeChip = (field: ChipField, value: string) => {
    if (!prefs) return
    const current = (prefs[field] as string[]) || []
    updateField(
      field as any,
      current.filter((item) => item !== value) as any
    )
  }

  const handleSave = async () => {
    await save()
  }

  const sectionHeader = (icon: React.ReactNode, label: string, desc: string) => (
    <div className="jobprefs-section-header">
      <div className="jobprefs-section-header-title">
        {icon}
        <span>{label}</span>
      </div>
      <p className="jobprefs-section-header-desc">
        {desc}
      </p>
    </div>
  )

  if (loading || !prefs) {
    return (
      <div className="jobprefs-page">
        <Container maxWidth="lg" padding="md">
          <div className="jobprefs-header">
            <div className="jobprefs-header-text">
              <div className="jobprefs-header-skeleton" />
              <div className="jobprefs-subtitle-skeleton" />
            </div>
          </div>
          <div className="jobprefs-card-list">
            <div className="jobprefs-loading-skeleton" />
            <div className="jobprefs-loading-skeleton" />
            <div className="jobprefs-loading-skeleton" />
          </div>
        </Container>
      </div>
    )
  }

  return (
    <div className="jobprefs-page">
      <Container maxWidth="lg" padding="md">
        <header className="jobprefs-header">
          <div className="jobprefs-header-text">
            <h1 className="jobprefs-title">Job preferences</h1>
            <p className="jobprefs-subtitle">
              Tell Relevnt what is worth your energy. We use this to score your matches,
              tune your Relevnt Feed, and set guardrails for auto apply, always on your
              terms and never shared with employers.
            </p>
          </div>
          <Link to="/settings" className="ghost-button button-sm">
            <PreferencesIcon size={16} strokeWidth={1.6} />
            <span>Settings</span>
          </Link>
        </header>

        <div className="jobprefs-card-list">
          {/* Target roles */}
          <article className="surface-card jobprefs-card">
            <div className="rl-field-grid">
              {sectionHeader(
                <JobsIcon size={18} strokeWidth={1.7} />,
                'Target roles',
                'We start from the titles that feel most like you, then branch into nearby options using live job market data.'
              )}
              <div style={{ display: 'grid', gap: 12 }}>
                <label className="rl-label">
                  Primary title
                  <input
                    className="rl-input"
                    type="text"
                    value={prefs.primary_title}
                    onChange={(e) => updateField('primary_title', e.target.value)}
                    placeholder="e.g., Senior Content Strategist"
                  />
                </label>

                <div>
                  <label className="rl-label">
                    Related titles
                    <input
                      className="rl-input"
                      type="text"
                      value={chipDrafts.related_titles}
                      onChange={(e) =>
                        setChipDrafts({
                          ...chipDrafts,
                          related_titles: e.target.value,
                        })
                      }
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault()
                          addChip('related_titles')
                        }
                      }}
                      placeholder="Add related titles one by one"
                    />
                  </label>
                  <div className="jobprefs-chips-row">
                    {prefs.related_titles.map((item) => (
                      <span key={item} className="jobprefs-chip">
                        {item}
                        <button
                          type="button"
                          onClick={() => removeChip('related_titles', item)}
                          className="jobprefs-chip-remove"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="rl-label">Seniority levels</label>
                  <div className="jobprefs-toggle-buttons">
                    {seniorityOptions.map((option) => {
                      const active = prefs.seniority_levels.includes(option)
                      return (
                        <button
                          key={option}
                          type="button"
                          onClick={() => {
                            const next = active
                              ? prefs.seniority_levels.filter((s) => s !== option)
                              : [...prefs.seniority_levels, option]
                            updateField('seniority_levels', next)
                          }}
                          className={`jobprefs-toggle-button ${active ? 'active' : ''}`}
                        >
                          {option}
                        </button>
                      )
                    })}
                  </div>
                </div>
              </div>
            </div>
            <div className="rl-help">
              We also use your saved jobs and resume to suggest nearby titles.
            </div>
          </article>

          {/* Work style */}
          <article className="surface-card jobprefs-card">
            <div className="rl-field-grid">
              {sectionHeader(
                <PreferencesIcon size={18} strokeWidth={1.7} />,
                'Work style',
                'Tell us how you actually work best so we can filter out roles that ignore your remote, hybrid, onsite, and timezone reality.'
              )}
              <div style={{ display: 'grid', gap: 12 }}>
                <label className="rl-label">Remote preference</label>
                <div className="jobprefs-toggle-buttons">
                  {locationOptions.map((option) => {
                    const value = option.toLowerCase()
                    const active = prefs.remote_preference === value
                    return (
                      <button
                        key={option}
                        type="button"
                        onClick={() => updateField('remote_preference', value)}
                        className={`jobprefs-toggle-button ${active ? 'active' : ''}`}
                      >
                        {option}
                      </button>
                    )
                  })}
                </div>

                <div>
                  <label className="rl-label">
                    Preferred locations
                    <input
                      className="rl-input"
                      type="text"
                      value={chipDrafts.preferred_locations}
                      onChange={(e) =>
                        setChipDrafts({
                          ...chipDrafts,
                          preferred_locations: e.target.value,
                        })
                      }
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault()
                          addChip('preferred_locations')
                        }
                      }}
                      placeholder="Cities or regions you are open to"
                    />
                  </label>
                  <div className="jobprefs-chips-row">
                    {prefs.preferred_locations.map((item) => (
                      <span key={item} className="jobprefs-chip">
                        {item}
                        <button
                          type="button"
                          onClick={() => removeChip('preferred_locations', item)}
                          className="jobprefs-chip-remove"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="rl-label">
                    Allowed timezones
                    <input
                      className="rl-input"
                      type="text"
                      value={chipDrafts.allowed_timezones}
                      onChange={(e) =>
                        setChipDrafts({
                          ...chipDrafts,
                          allowed_timezones: e.target.value,
                        })
                      }
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault()
                          addChip('allowed_timezones')
                        }
                      }}
                      placeholder="Optional: add timezones you align with"
                    />
                  </label>
                  <div className="jobprefs-chips-row">
                    {prefs.allowed_timezones.map((item) => (
                      <span key={item} className="jobprefs-chip">
                        {item}
                        <button
                          type="button"
                          onClick={() => removeChip('allowed_timezones', item)}
                          className="jobprefs-chip-remove"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </article>

          {/* Compensation */}
          <article className="surface-card jobprefs-card">
            <div className="rl-field-grid">
              {sectionHeader(
                <PreferencesIcon size={18} strokeWidth={1.7} />,
                'Compensation',
                'This never gets shared with employers. It helps us compare your floor to current ranges and hide roles that are not financially respectful.'
              )}
              <div style={{ display: 'grid', gap: 12 }}>
                <label className="rl-label">
                  Minimum base salary
                  <div className="jobprefs-salary-row">
                    <input
                      className="rl-input jobprefs-salary-input"
                      type="number"
                      value={prefs.min_salary ?? ''}
                      onChange={(e) =>
                        updateField(
                          'min_salary',
                          e.target.value ? Number(e.target.value) : null
                        )
                      }
                      placeholder="e.g., 95000"
                    />
                    <select
                      className="rl-select jobprefs-salary-select"
                      value={prefs.salary_currency}
                      onChange={(e) =>
                        updateField('salary_currency', e.target.value)
                      }
                    >
                      {currencyOptions.map((opt) => (
                        <option key={opt} value={opt}>
                          {opt}
                        </option>
                      ))}
                    </select>
                    <select
                      className="rl-select jobprefs-salary-select"
                      value={prefs.salary_unit}
                      onChange={(e) =>
                        updateField(
                          'salary_unit',
                          e.target.value as JobPreferences['salary_unit']
                        )
                      }
                    >
                      {salaryUnitOptions.map((opt) => (
                        <option key={opt} value={opt}>
                          {opt}
                        </option>
                      ))}
                    </select>
                  </div>
                </label>
              </div>
            </div>
          </article>

          {/* Keywords & filters */}
          <article className="surface-card jobprefs-card">
            <div className="rl-field-grid">
              {sectionHeader(
                <PreferencesIcon size={18} strokeWidth={1.7} />,
                'Keywords & filters',
                'Tell Relevnt what language feels like a green flag or a red flag so we can gently up-rank or down-rank roles in your feed.'
              )}
              <div style={{ display: 'grid', gap: 12 }}>
                <div>
                  <label className="rl-label">
                    Keywords to lean toward
                    <input
                      className="rl-input"
                      type="text"
                      value={chipDrafts.include_keywords}
                      onChange={(e) =>
                        setChipDrafts({
                          ...chipDrafts,
                          include_keywords: e.target.value,
                        })
                      }
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault()
                          addChip('include_keywords')
                        }
                      }}
                      placeholder="e.g., ethical AI, non-profit, public health, climate, women-led"
                    />
                  </label>
                  <div className="jobprefs-chips-row">
                    {prefs.include_keywords?.map((item) => (
                      <span key={item} className="jobprefs-chip">
                        {item}
                        <button
                          type="button"
                          onClick={() => removeChip('include_keywords', item)}
                          className="jobprefs-chip-remove"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                  <div className="rl-help">
                    Think of these as "this looks like my lane" signals. We use them to gently boost
                    jobs that sound like your people.
                  </div>
                </div>

                <div>
                  <label className="rl-label">
                    Words or phrases to avoid
                    <input
                      className="rl-input"
                      type="text"
                      value={chipDrafts.avoid_keywords}
                      onChange={(e) =>
                        setChipDrafts({
                          ...chipDrafts,
                          avoid_keywords: e.target.value,
                        })
                      }
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault()
                          addChip('avoid_keywords')
                        }
                      }}
                      placeholder="e.g., crypto, MLM, unpaid, commission only, hustle, rockstar"
                    />
                  </label>
                  <div className="jobprefs-chips-row">
                    {prefs.avoid_keywords?.map((item) => (
                      <span key={item} className="jobprefs-chip">
                        {item}
                        <button
                          type="button"
                          onClick={() => removeChip('avoid_keywords', item)}
                          className="jobprefs-chip-remove"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                  <div className="rl-help">
                    We use these as soft filters and down-rank signals, not hard blocks, so you never
                    miss something genuinely aligned that uses messy language.
                  </div>
                </div>
              </div>
            </div>
          </article>

          {/* Safeties */}
          <article className="surface-card jobprefs-card">
            <div className="rl-field-grid">
              {sectionHeader(
                <PreferencesIcon size={18} strokeWidth={1.7} />,
                'Safeties',
                'Hard boundaries so you do not waste time or emotional energy.'
              )}
              <div style={{ display: 'grid', gap: 12 }}>
                <div>
                  <label className="rl-label">
                    Titles to avoid
                    <input
                      className="rl-input"
                      type="text"
                      value={chipDrafts.exclude_titles}
                      onChange={(e) =>
                        setChipDrafts({
                          ...chipDrafts,
                          exclude_titles: e.target.value,
                        })
                      }
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault()
                          addChip('exclude_titles')
                        }
                      }}
                      placeholder="Add titles you will not consider"
                    />
                  </label>
                  <div className="jobprefs-chips-row">
                    {prefs.exclude_titles.map((item) => (
                      <span key={item} className="jobprefs-chip">
                        {item}
                        <button
                          type="button"
                          onClick={() => removeChip('exclude_titles', item)}
                          className="jobprefs-chip-remove"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="rl-label">
                    Companies to avoid
                    <input
                      className="rl-input"
                      type="text"
                      value={chipDrafts.exclude_companies}
                      onChange={(e) =>
                        setChipDrafts({
                          ...chipDrafts,
                          exclude_companies: e.target.value,
                        })
                      }
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault()
                          addChip('exclude_companies')
                        }
                      }}
                      placeholder="Add companies to skip"
                    />
                  </label>
                  <div className="jobprefs-chips-row">
                    {prefs.exclude_companies.map((item) => (
                      <span key={item} className="jobprefs-chip">
                        {item}
                        <button
                          type="button"
                          onClick={() => removeChip('exclude_companies', item)}
                          className="jobprefs-chip-remove"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="rl-label">
                    Contract types to exclude
                    <input
                      className="rl-input"
                      type="text"
                      value={chipDrafts.exclude_contract_types}
                      onChange={(e) =>
                        setChipDrafts({
                          ...chipDrafts,
                          exclude_contract_types: e.target.value,
                        })
                      }
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault()
                          addChip('exclude_contract_types')
                        }
                      }}
                      placeholder="Add contract types to avoid"
                    />
                  </label>
                  <div className="rl-help">
                    Examples: unpaid internship, 1099 only, commission only.
                  </div>
                  <div className="jobprefs-chips-row">
                    {prefs.exclude_contract_types.map((item) => (
                      <span key={item} className="jobprefs-chip">
                        {item}
                        <button
                          type="button"
                          onClick={() =>
                            removeChip('exclude_contract_types', item)
                          }
                          className="jobprefs-chip-remove"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </article>

          {/* Auto apply */}
          <article className="surface-card jobprefs-card">
            <div className="rl-field-grid">
              {sectionHeader(
                <AutoApplyIcon size={18} strokeWidth={1.7} />,
                'Auto apply guardrails',
                'If you turn on auto apply, these are the rules we follow, including preferring the employer site when available so your applications look intentional, not spray and pray.'
              )}
              <div style={{ display: 'grid', gap: 12 }}>
                <label className="jobprefs-checkbox-label">
                  <input
                    type="checkbox"
                    checked={prefs.enable_auto_apply}
                    onChange={(e) =>
                      updateField('enable_auto_apply', e.target.checked)
                    }
                    className="jobprefs-checkbox"
                  />
                  <span>Allow Relevnt to auto-apply on my behalf</span>
                </label>

                <label className="rl-label">
                  Minimum match score
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <MatchScoreIcon size={16} strokeWidth={1.6} />
                    <input
                      className="rl-input jobprefs-salary-input"
                      type="number"
                      min={0}
                      max={100}
                      value={prefs.auto_apply_min_match_score ?? ''}
                      onChange={(e) =>
                        updateField(
                          'auto_apply_min_match_score',
                          e.target.value ? Number(e.target.value) : null
                        )
                      }
                      placeholder="e.g., 85"
                    />
                  </div>
                </label>

                <label className="rl-label">
                  Maximum auto applications per day
                  <input
                    className="rl-input"
                    type="number"
                    min={0}
                    value={prefs.auto_apply_max_apps_per_day ?? ''}
                    onChange={(e) =>
                      updateField(
                        'auto_apply_max_apps_per_day',
                        e.target.value ? Number(e.target.value) : null
                      )
                    }
                    placeholder="e.g., 5"
                  />
                </label>
              </div>
            </div>
          </article>
        </div>

        <div className="jobprefs-footer">
          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="primary-button"
            style={{ opacity: saving ? 0.7 : 1, cursor: saving ? 'not-allowed' : 'pointer' }}
          >
            {saving ? 'Saving…' : 'Save preferences'}
          </button>
          {saveStatus === 'saved' && (
            <span className="jobprefs-save-status">
              Saved
            </span>
          )}
          {saveStatus === 'error' && (
            <span className="jobprefs-save-error">
              We could not save your preferences. Try again.
            </span>
          )}
          {error && (
            <span className="jobprefs-save-error">{error}</span>
          )}
        </div>
      </Container>
    </div>
  )
}
