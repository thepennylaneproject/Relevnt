// src/pages/ResumeBuilderPage.tsx
import * as React from 'react'
import { useState, useMemo } from 'react'

import PageBackground from '../components/shared/PageBackground'
import { Container } from '../components/shared/Container'
import { ContactSection } from '../components/ResumeBuilder/ContactSection'
import { SummarySection } from '../components/ResumeBuilder/SummarySection'
import { SkillsSection } from '../components/ResumeBuilder/SkillsSection'
import { ExperienceSection } from '../components/ResumeBuilder/ExperienceSection'
import { EducationSection } from '../components/ResumeBuilder/EducationSection'
import { CertificationsSection } from '../components/ResumeBuilder/CertificationsSection'
import { ProjectsSection } from '../components/ResumeBuilder/ProjectsSection'
import { SectionCard } from '../components/ResumeBuilder/SectionCard'
import { ResumePreview } from '../components/ResumeBuilder/ResumePreview'
import { useRelevntColors } from '../hooks/useRelevntColors'
import type { ResumeDraft } from '../types/resume-builder.types'

import {
  User,
  FileText,
  Sparkles,
  Briefcase,
  GraduationCap,
  Award,
  FolderKanban,
} from 'lucide-react'

type ActiveSection =
  | 'contact'
  | 'summary'
  | 'skills'
  | 'experience'
  | 'education'
  | 'certifications'
  | 'projects'

const SECTION_META: {
  id: ActiveSection
  label: string
  icon: React.ReactNode
}[] = [
    { id: 'contact', label: 'Contact', icon: <User className="w-4 h-4" /> },
    { id: 'summary', label: 'Summary', icon: <FileText className="w-4 h-4" /> },
    { id: 'skills', label: 'Skills', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'experience', label: 'Experience', icon: <Briefcase className="w-4 h-4" /> },
    { id: 'education', label: 'Education', icon: <GraduationCap className="w-4 h-4" /> },
    { id: 'certifications', label: 'Certifications', icon: <Award className="w-4 h-4" /> },
    { id: 'projects', label: 'Projects', icon: <FolderKanban className="w-4 h-4" /> },
  ]

const ResumeBuilderPage: React.FC = () => {
  const [activeSection, setActiveSection] = useState<ActiveSection>('contact')

  // shared state (can tighten types later)
  const [contact, setContact] = useState<any>({})
  const [summary, setSummary] = useState<any>('')
  const [skillGroups, setSkillGroups] = useState<any[]>([])
  const [experienceItems, setExperienceItems] = useState<any[]>([])
  const [educationItems, setEducationItems] = useState<any[]>([])
  const [certificationItems, setCertificationItems] = useState<any[]>([])
  const [projectItems, setProjectItems] = useState<any[]>([])

  const colors = useRelevntColors()

  const draft: ResumeDraft = useMemo(
    () =>
    ({
      contact,
      summary: { summary },
      experience: experienceItems,
      education: educationItems,
      skillGroups,
      projects: projectItems,
      certifications: certificationItems,
    } as ResumeDraft),
    [
      contact,
      summary,
      experienceItems,
      educationItems,
      skillGroups,
      projectItems,
      certificationItems,
    ]
  )

  return (
    <PageBackground>
      <Container maxWidth="xl" padding="md">
        <div className="resume-page">
          {/* HERO */}
          <section className="hero-shell">
            <div className="hero-header">
              <div className="hero-icon">
                <FileText className="w-5 h-5 text-graphite" aria-hidden="true" />
              </div>
              <div className="hero-header-main">
                <p className="text-xs muted">CVs</p>
                <h1>Resume builder</h1>
                <p className="muted">
                  Tune your resume once. Reuse it everywhere. Edit each section in plain language,
                  Relevnt keeps your structure consistent and later we can layer in AI helpers for tailoring.
                </p>
              </div>
            </div>

            <div className="hero-actions-accent">
              <nav className="resume-section-nav">
                {SECTION_META.map((section) => {
                  const isActive = section.id === activeSection
                  return (
                    <button
                      key={section.id}
                      type="button"
                      onClick={() => setActiveSection(section.id)}
                      className={`resume-section-nav-btn ${isActive ? 'resume-section-nav-btn--active' : ''}`}
                    >
                      {section.icon}
                      <span className="sr-only">{section.label}</span>
                    </button>
                  )
                })}
              </nav>
            </div>
          </section>

          {/* EDITOR + PREVIEW IN 2-COLUMN GRID */}
          <section className="page-two-column">
            {/* LEFT: active editor section */}
            <div className="card-shell card-shell--soft">

            {activeSection === 'contact' && (
              <ContactSection contact={contact} onChange={setContact} />
            )}

            {activeSection === 'summary' && (
              <SummarySection summary={summary} onChange={setSummary} />
            )}

            {activeSection === 'skills' && (
              <SkillsSection
                id="skills"
                skillGroups={skillGroups}
                onChange={setSkillGroups}
                colors={colors}
              />
            )}

            {activeSection === 'experience' && (
              <ExperienceSection
                id="experience"
                items={experienceItems}
                onChange={setExperienceItems}
                colors={colors}
              />
            )}

            {activeSection === 'education' && (
              <EducationSection
                id="education"
                items={educationItems}
                onChange={setEducationItems}
                colors={colors}
              />
            )}

            {activeSection === 'certifications' && (
              <CertificationsSection
                id="certifications"
                items={certificationItems}
                onChange={setCertificationItems}
                colors={colors}
              />
            )}

            {activeSection === 'projects' && (
              <ProjectsSection
                id="projects"
                items={projectItems}
                onChange={setProjectItems}
                colors={colors}
              />
            )}
          </div>

            {/* RIGHT: preview card */}
            <div className="card-shell card-shell--soft">
              <div>
                <h2 className="text-sm font-semibold">Preview</h2>
                <p className="muted text-xs">
                  Your resume layout will update as you fill in each section.
                </p>
              </div>
              <ResumePreview draft={draft} />
            </div>
          </section>
        </div>
      </Container>
    </PageBackground>
  )
}

export default ResumeBuilderPage
