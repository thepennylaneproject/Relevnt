import React from 'react'
import SettingsPage from './SettingsPage'

// Temporary alias until dedicated profile sections are split.
export default function ProfilePersonalPage() {
  return <SettingsPage />
}
