import React from 'react'
import { useLocation, Link } from 'react-router-dom'
import {
  LayoutDashboard,
  Briefcase,
  FileText,
  FileUser,
  GraduationCap,
  MessageSquare,
  Settings,
} from 'lucide-react'
import { useRelevntColors } from '../../hooks'

const NAV_ITEMS = [
  { path: '/dashboard', label: 'Dash', Icon: LayoutDashboard },
  { path: '/jobs', label: 'Jobs', Icon: Briefcase },
  { path: '/applications', label: 'Apps', Icon: FileText },
  { path: '/resumes', label: 'CVs', Icon: FileUser },
  { path: '/learn', label: 'Learn', Icon: GraduationCap },
  { path: '/voice', label: 'Voice', Icon: MessageSquare },
  { path: '/settings', label: 'Prefs', Icon: Settings },
]

const DOODLES: Record<string, string> = {
  '/dashboard': '/doodles/sidebar-roadmap.svg',
  '/jobs': '/doodles/sidebar-constellation.svg',
  '/applications': '/doodles/sidebar-notebook.svg',
  '/resumes': '/doodles/sidebar-tools.svg',
  '/learn': '/doodles/sidebar-wanderer.svg',
  '/voice': '/doodles/sidebar-notes.svg',
  '/settings': '/doodles/sidebar-phoenix.svg',
}

export default function SidebarMarginNav() {
  const { pathname } = useLocation()
  const colors = useRelevntColors()
  const active = (path: string) => pathname.startsWith(path)
  const doodle =
    DOODLES[Object.keys(DOODLES).find((p) => pathname.startsWith(p)) ?? '/dashboard']

  return (
    <aside
      className="margin-nav"
      style={
        {
          '--nav-bg': colors.surface,
          '--nav-border': colors.borderLight,
          '--nav-ink': colors.text,
          '--nav-muted': colors.textSecondary,
          '--nav-accent': colors.primary,
          '--nav-hover-bg': colors.surfaceHover,
          '--nav-active-bg': colors.focus,
        } as React.CSSProperties
      }
    >
      <div className="margin-nav__doodle">
        <img src={doodle} alt="" />
      </div>

      <nav className="margin-nav__nav">
        <ul>
          {NAV_ITEMS.map(({ path, label, Icon }) => {
            const isActive = active(path)
            return (
              <li key={path}>
                <Link to={path} className={`margin-nav__item${isActive ? ' active' : ''}`}>
                  <span className="margin-nav__icon icon-nav">
                    <Icon size={20} strokeWidth={2} color={isActive ? colors.primary : colors.text} />
                  </span>
                  <span className="margin-nav__label">{label}</span>
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>
    </aside>
  )
}
