/**
 * ═══════════════════════════════════════════════════════════════════════════
 * RELEVNT EMPTY STATE COMPONENT
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Displays a helpful, motivating message when a section has no content.
 * Uses brand voice: "Be clear. Be kind. Be accountable."
 * 
 * Design principle: Empty states should feel like the beginning of something,
 * not the absence of something.
 * 
 * Usage:
 *   <EmptyState
 *     type="applications"
 *     action={{ label: "Browse jobs", onClick: () => navigate('/jobs') }}
 *   />
 * 
 * ═══════════════════════════════════════════════════════════════════════════
 */

import React from 'react';
import { Button } from './Button';

// ═══════════════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════════════

export type EmptyStateType =
  | 'applications'
  | 'jobs'
  | 'resumes'
  | 'saved'
  | 'matches'
  | 'search'
  | 'learn'
  | 'analysis'
  | 'generic';

export interface EmptyStateAction {
  label: string;
  onClick: () => void;
  variant?: 'primary' | 'secondary';
}

export interface EmptyStateProps {
  type: EmptyStateType;
  /** Override the default title */
  title?: string;
  /** Override the default description */
  description?: string;
  /** Primary action button */
  action?: EmptyStateAction;
  /** Secondary action button */
  secondaryAction?: EmptyStateAction;
  /** Additional CSS classes */
  className?: string;
}

// ═══════════════════════════════════════════════════════════════════════════
// EMPTY STATE CONTENT
// Copy follows brand voice guide: motivational, not scolding
// ═══════════════════════════════════════════════════════════════════════════

interface EmptyStateContent {
  title: string;
  description: string;
}

const emptyStateContent: Record<EmptyStateType, EmptyStateContent> = {
  applications: {
    title: "Your story starts here",
    description: "When you apply to your first role, we'll track every step together — no spreadsheets required.",
  },
  
  jobs: {
    title: "Fresh opportunities await",
    description: "We haven't found jobs matching your criteria yet. Try adjusting your filters or check back soon.",
  },
  
  resumes: {
    title: "Your story, ready to unfold",
    description: "Upload a résumé to see how the system sees you — and how to make it see you better.",
  },
  
  saved: {
    title: "Nothing saved yet",
    description: "When you find a role worth holding onto, save it here. We'll keep it safe.",
  },
  
  matches: {
    title: "Finding your direction",
    description: "Once we know more about you, we'll surface roles that actually fit.",
  },
  
  search: {
    title: "No results found",
    description: "We couldn't find what you're looking for. Try different keywords or broaden your search.",
  },
  
  learn: {
    title: "Coming soon",
    description: "We're building resources to close the gaps the market cares about — without signing your life away to another bootcamp.",
  },
  
  analysis: {
    title: "No analyses yet",
    description: "Paste a job post or upload a résumé to see how the system sees you. We'll show our work.",
  },
  
  generic: {
    title: "Nothing here yet",
    description: "This space is waiting for you. Let's get started.",
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// COMPONENT
// ═══════════════════════════════════════════════════════════════════════════

export const EmptyState: React.FC<EmptyStateProps> = ({
  type,
  title,
  description,
  action,
  secondaryAction,
  className = '',
}) => {
  const content = emptyStateContent[type] || emptyStateContent.generic;

  const displayTitle = title || content.title;
  const displayDescription = description || content.description;

  return (
    <div className={`empty-state ${className}`}>
      {/* Title */}
      <h3 className="empty-state__title">
        {displayTitle}
      </h3>

      {/* Description */}
      <p className="empty-state__description">
        {displayDescription}
      </p>

      {/* Actions */}
      {(action || secondaryAction) && (
        <div className="empty-state__actions">
          {action && (
            <Button
              type="button"
              onClick={action.onClick}
              variant={action.variant === 'secondary' ? 'secondary' : 'primary'}
            >
              {action.label}
            </Button>
          )}
          {secondaryAction && (
            <Button
              type="button"
              onClick={secondaryAction.onClick}
              variant={secondaryAction.variant === 'primary' ? 'primary' : 'secondary'}
            >
              {secondaryAction.label}
            </Button>
          )}
        </div>
      )}
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// STYLES (can be moved to CSS or Tailwind)
// ═══════════════════════════════════════════════════════════════════════════

export const emptyStateStyles = `
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: var(--space-12) var(--space-6);
  max-width: 400px;
  margin: 0 auto;
}

.empty-state__title {
  font-family: var(--font-display);
  font-size: var(--text-xl);
  font-weight: var(--font-semibold);
  color: var(--color-ink);
  margin: 0 0 var(--space-2);
}

.empty-state__description {
  font-size: var(--text-base);
  color: var(--color-ink-secondary);
  margin: 0 0 var(--space-6);
  line-height: var(--leading-relaxed);
}

.empty-state__actions {
  display: flex;
  gap: var(--space-3);
  flex-wrap: wrap;
  justify-content: center;
  margin-top: var(--space-8);
}
`;

export default EmptyState;
