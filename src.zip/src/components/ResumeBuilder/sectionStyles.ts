export const labelClass =
    'mb-1 block text-xs font-medium text-neutral-800';

export const helperClass =
    'text-xs text-neutral-500';

export const inputClass =
    'w-full rounded-xl border border-[rgba(0,0,0,0.08)] bg-white px-3 py-2.5 text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-[rgba(194,166,112,0.45)] focus:border-[rgba(194,166,112,0.9)]';

export const textareaClass = `${inputClass} min-h-[120px] resize-y`;

export const addButtonClass =
    'inline-flex items-center gap-1.5 rounded-full border border-dashed border-[rgba(194,166,112,0.7)] bg-white px-3 py-1.5 text-xs font-semibold text-neutral-800 shadow-sm transition hover:bg-[#f8f2e5] hover:-translate-y-[1px] cursor-pointer';

export const removeButtonClass =
    'inline-flex items-center gap-1.5 rounded-full border border-rose-200 bg-rose-50 px-3 py-1.5 text-xs font-semibold text-rose-600 transition hover:bg-rose-100 hover:-translate-y-[1px] cursor-pointer';

export const itemCardClass =
    'space-y-3 rounded-2xl border border-[rgba(0,0,0,0.06)] bg-white p-4 shadow-sm';